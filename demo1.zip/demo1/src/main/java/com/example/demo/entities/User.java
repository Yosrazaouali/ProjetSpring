package com.example.demo.entities;


import com.example.demo.enums.Role;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "t_user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long idUser;

    @Column(name = "nom")
    private String nom;
    @Column(name = "prenom")
    private String prenom;
    @Column(name = "email")
    private String email;
    @Column(name = "password")
    private String psw;

    @ManyToMany(fetch = FetchType.EAGER)
    private Set<Projet> projets;

    @Column(name = "role")
    public Role role;

}

