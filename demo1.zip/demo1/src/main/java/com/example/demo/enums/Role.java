package com.example.demo.enums;

public enum Role {

    SCRUM_MASTER,
    PRODUCT_OWNER,
    DEVELOPER,
    CLIENT
}
