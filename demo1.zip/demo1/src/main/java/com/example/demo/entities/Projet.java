package com.example.demo.entities;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "t_projet")
public class Projet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long idprojet;

    @Column(name = "titre")
    private String titre;
    @Column(name = "description")
    private String description;
    @ManyToMany(mappedBy = "projets", cascade = CascadeType.ALL)
    private Set<User> users;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "projet")
    private Set<Sprint> Sprints;
}
